/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import control.EmpleadoJpaController;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

/**
 *
 * @author Biani
 */
public class EmpleadoTableModel extends AbstractTableModel {

    private final String[] columnas = {"ID", "Nombre", "Puesto", "Horario"};
    private List<Empleado> empleados;
    private boolean modoEdicion = false;
    private EmpleadoJpaController controller;
    private List<Empleado> empleadosOriginales = new ArrayList<>();
    private Integer empleadoFiltradoId = null;

    public EmpleadoTableModel(List<Empleado> empleados, EmpleadoJpaController controller) {
        //this.empleados = new ArrayList<>(empleados);

        this.empleados = new ArrayList<>();
        this.empleadosOriginales = new ArrayList<>();
        this.controller = controller;

        if (empleados != null) {
            for (Empleado e : empleados) {
                Empleado copia = clonarEmpleado(e);
                this.empleados.add(copia);
                this.empleadosOriginales.add(clonarEmpleado(copia));
            }
        }
    }

    @Override
    public int getRowCount() {
        return empleados.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int c) {
        return columnas[c];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 0) {
            return Long.class; // Para el ID
        }
        return String.class; // Para los demás campos
    }

    @Override
    public Object getValueAt(int r, int c) {
        Empleado emp = empleados.get(r);
        switch (c) {
            case 0:
                return emp.getIdEmpleado();
            case 1:
                return emp.getNombreEmpleado();
            case 2:
                return emp.getPuesto();
            case 3:
                return emp.getHorario();
            default:
                return null;
        }
    }

    @Override
    public boolean isCellEditable(int r, int c) {
        return modoEdicion && c != 0; // no permitir editar ID
    }

//    @Override
//    public void setValueAt(Object dato, int r, int c) {
//        Empleado emp = empleados.get(r);
//        switch (c) {
//            case 1:
//                emp.setNombreEmpleado(dato.toString());
//                break;
//            case 2:
//                emp.setPuesto(dato.toString());
//                break;
//            case 3:
//                emp.setHorario(dato.toString());
//                break;
//        }
//        fireTableCellUpdated(r, c);
//    }
    public void setModoEdicion(boolean modoEdicion) {
        this.modoEdicion = modoEdicion;
        fireTableDataChanged(); 
    }

//    public List<Empleado> getEmpleadosModificados() {
//        return empleados.stream()
//                .filter(emp -> {
//                    try {
//                        Empleado original = controller.findEmpleado(emp.getIdEmpleado());
//                        return !emp.equals(original);
//                    } catch (Exception e) {
//                        return false;
//                    }
//                })
//                .collect(Collectors.toList());
//    }
    public void resetFilter() {
        this.empleadoFiltradoId = null;
    }

    private Empleado buscarOriginalPorId(Integer id) {
        if (id == null) {
            return null;
        }

        return empleadosOriginales.stream()
                .filter(original -> original != null
                && original.getIdEmpleado() != null
                && original.getIdEmpleado().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Empleado> getEmpleadosModificados() {
        List<Empleado> modificados = new ArrayList<>();

        for (Empleado actual : empleados) {
            // Para empleados nuevos (sin ID)
            if (actual.getIdEmpleado() == null) {
                modificados.add(actual);
                continue;
            }

            // Buscar el original correspondiente
            Empleado original = empleadosOriginales.stream()
                    .filter(o -> o != null && actual.getIdEmpleado().equals(o.getIdEmpleado()))
                    .findFirst()
                    .orElse(null);

            // Si no existe original, es nuevo
            if (original == null) {
                modificados.add(actual);
                continue;
            }

            // Comparar cada campo relevante
            if (!Objects.equals(actual.getNombreEmpleado(), original.getNombreEmpleado())
                    || !Objects.equals(actual.getPuesto(), original.getPuesto())
                    || !Objects.equals(actual.getHorario(), original.getHorario())) {

                System.out.println("Diferencia encontrada para ID " + actual.getIdEmpleado() + ":");
                System.out.println("Nombre: " + original.getNombreEmpleado() + " -> " + actual.getNombreEmpleado());
                System.out.println("Puesto: " + original.getPuesto() + " -> " + actual.getPuesto());
                System.out.println("Horario: " + original.getHorario() + " -> " + actual.getHorario());

                modificados.add(actual);
            }
        }

        return modificados;
    }

    public Empleado getEmpleadoAt(int r) {
        return empleados.get(r);
    }

    public void eliminarEmpleado(int r) {
        empleados.remove(r);
        fireTableRowsDeleted(r, r);
    }

    public void actualizarLista(List<Empleado> nuevos) {
        this.empleados = nuevos;
        fireTableDataChanged();
    }

    public void notificarCambios() {
        fireTableDataChanged();
    }

    public void setEmpleados(List<Empleado> nuevosEmpleados) {
    this.empleados.clear();
    
    if (nuevosEmpleados != null) {
        // Clonar para evitar referencia directa
        for (Empleado e : nuevosEmpleados) {
            this.empleados.add(clonarEmpleado(e));
        }
    }
    
    fireTableDataChanged();
    System.out.println("Modelo actualizado con " + this.empleados.size() + " empleados");
}

//    public void actualizarDatosCompletos(List<Empleado> nuevosDatos) {
//        this.empleados = new ArrayList<>(nuevosDatos);
//        fireTableDataChanged();
//    }
    public void agregarEmpleado(Empleado empleado) {
        this.empleados.add(empleado);
        fireTableRowsInserted(empleados.size() - 1, empleados.size() - 1);
    }

//    // Método para actualizar toda la lista
//    public void setEmpleados(List<Empleado> empleados) {
//        this.empleados = new ArrayList<>(empleados);
//        fireTableDataChanged();
//    }
    public Empleado clonarEmpleado(Empleado original) {
    if (original == null) {
        return null;
    }
    
    Empleado copia = new Empleado();
    copia.setIdEmpleado(original.getIdEmpleado());
    copia.setNombreEmpleado(original.getNombreEmpleado());
    copia.setPuesto(original.getPuesto());
    copia.setHorario(original.getHorario());
    // Copia otros campos si existen
    return copia;
}
    public void actualizarDatosCompletos(List<Empleado> nuevosDatos) {
    this.empleados.clear();
    this.empleadosOriginales.clear();
    
    if (nuevosDatos != null) {
        for (Empleado e : nuevosDatos) {
            Empleado copia = clonarEmpleado(e);
            this.empleados.add(copia);
            this.empleadosOriginales.add(clonarEmpleado(copia));
        }
    }
    
    fireTableDataChanged();
}

    public void setEmpleadosFiltrados(List<Empleado> filtrados, Integer idFiltrado) {
        // Mantener una copia de la lista completa
        List<Empleado> copiaFiltrados = new ArrayList<>();
        for (Empleado e : filtrados) {
            copiaFiltrados.add(clonarEmpleado(e));
        }

        this.empleadoFiltradoId = idFiltrado;
        this.empleados = copiaFiltrados;
        fireTableDataChanged();
    }

   // En tu EmpleadoTableModel, modifica setValueAt:
@Override
public void setValueAt(Object value, int row, int column) {
    Empleado emp = empleados.get(row);
    String valor = (value != null) ? value.toString().trim() : ""; // Evitar NullPointerException y trim()

    try {
        switch (column) {
            case 1: // Nombre
                if (valor.isEmpty()) {
                    throw new IllegalArgumentException("El nombre no puede estar vacío");
                }
                if (!valor.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
                    throw new IllegalArgumentException("El nombre solo puede contener letras y espacios");
                }
                emp.setNombreEmpleado(valor);
                break;
                
            case 2: // Puesto
                if (valor.isEmpty()) {
                    throw new IllegalArgumentException("El puesto no puede estar vacío");
                }
                if (!valor.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ]+")) {
                    throw new IllegalArgumentException("El puesto solo puede contener letras sin espacios");
                }
                emp.setPuesto(valor);
                break;
                
            case 3: // Horario
                if (valor.isEmpty()) {
                    throw new IllegalArgumentException("El horario no puede estar vacío");
                }
                if (!valor.matches("^([01]?[0-9]|2[0-3]):[0-5][0-9]-([01]?[0-9]|2[0-3]):[0-5][0-9]$")) {
                    throw new IllegalArgumentException("Formato de horario inválido. Debe ser HH:MM-HH:MM (ej. 08:00-16:00)");
                }
                emp.setHorario(valor);
                break;
                
            default:
                return; // No hacer nada si la columna no es editable
        }
        
        fireTableCellUpdated(row, column); // Solo si la actualización fue exitosa
        
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(
            null,
            e.getMessage(),
            "Error de validación",
            JOptionPane.ERROR_MESSAGE
        );
        // No se llama a fireTableCellUpdated porque no hubo cambio válido
    }
}
    private void setValueForEmployee(Empleado emp, int column, Object value) {
        String valorAnterior = null;
        switch (column) {
            case 1:
                valorAnterior = emp.getNombreEmpleado();
                if (!Objects.equals(value, valorAnterior)) {
                    emp.setNombreEmpleado(value.toString());
                }
                break;
            case 2:
                valorAnterior = emp.getPuesto();
                if (!Objects.equals(value, valorAnterior)) {
                    emp.setPuesto(value.toString());
                }
                break;
            case 3:
                valorAnterior = emp.getHorario();
                if (!Objects.equals(value, valorAnterior)) {
                    emp.setHorario(value.toString());
                }
                break;
        }
    }

}
