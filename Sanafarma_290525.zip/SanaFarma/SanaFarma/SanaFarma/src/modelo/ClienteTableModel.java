/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import control.ClienteJpaController;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Biani
 */
public class ClienteTableModel extends AbstractTableModel {

    private final String[] columnas = {"ID", "Nombre", "Teléfono", "Correo"};
    private List<Cliente> clientes;
    private boolean modoEdicion = false;
    private ClienteJpaController controller;
    private List<Cliente> clientesOriginales = new ArrayList<>();
    private Integer clienteFiltradoId = null;

    public ClienteTableModel(List<Cliente> clientes, ClienteJpaController controller) {
        this.clientes = new ArrayList<>();
        this.clientesOriginales = new ArrayList<>();
        this.controller = controller;

        if (clientes != null) {
            for (Cliente c : clientes) {
                Cliente copia = clonarCliente(c);
                this.clientes.add(copia);
                this.clientesOriginales.add(clonarCliente(copia));
            }
        }
    }

    @Override
    public int getRowCount() {
        return clientes.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int c) {
        return columnas[c];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 0) {
            return Long.class; // Para el ID
        }
        return String.class; // Para los demás campos
    }

    @Override
    public Object getValueAt(int r, int c) {
        Cliente cli = clientes.get(r);
        switch (c) {
            case 0:
                return cli.getIdCliente();
            case 1:
                return cli.getNombreCliente();
            case 2:
                return cli.getTelefono();
            case 3:
                return cli.getCorreo();
            default:
                return null;
        }
    }

    @Override
    public boolean isCellEditable(int r, int c) {
        return modoEdicion && c != 0; // no permitir editar ID
    }

    public void setModoEdicion(boolean modoEdicion) {
        this.modoEdicion = modoEdicion;
        fireTableDataChanged();
    }

    public void resetFilter() {
        this.clienteFiltradoId = null;
    }

    private Cliente buscarOriginalPorId(Integer id) {
        if (id == null) {
            return null;
        }

        return clientesOriginales.stream()
                .filter(original -> original != null
                && original.getIdCliente() != null
                && original.getIdCliente().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Cliente> getClientesModificados() {
        List<Cliente> modificados = new ArrayList<>();

        for (Cliente actual : clientes) {
            // Para clientes nuevos (sin ID)
            if (actual.getIdCliente() == null) {
                modificados.add(actual);
                continue;
            }

            // Buscar el original correspondiente
            Cliente original = clientesOriginales.stream()
                    .filter(o -> o != null && actual.getIdCliente().equals(o.getIdCliente()))
                    .findFirst()
                    .orElse(null);

            // Si no existe original, es nuevo
            if (original == null) {
                modificados.add(actual);
                continue;
            }

            // Comparar cada campo 
            if (!Objects.equals(actual.getNombreCliente(), original.getNombreCliente())
                    || !Objects.equals(actual.getTelefono(), original.getTelefono())
                    || !Objects.equals(actual.getCorreo(), original.getCorreo())) {

                System.out.println("Diferencia encontrada para ID " + actual.getIdCliente() + ":");
                System.out.println("Nombre: " + original.getNombreCliente() + " -> " + actual.getNombreCliente());
                System.out.println("Teléfono: " + original.getTelefono() + " -> " + actual.getTelefono());
                System.out.println("Correo: " + original.getCorreo() + " -> " + actual.getCorreo());

                modificados.add(actual);
            }
        }

        return modificados;
    }

    public Cliente getClienteAt(int r) {
        return clientes.get(r);
    }

    public void eliminarCliente(int r) {
        clientes.remove(r);
        fireTableRowsDeleted(r, r);
    }

    public void actualizarLista(List<Cliente> nuevos) {
        this.clientes = nuevos;
        fireTableDataChanged();
    }

    public void notificarCambios() {
        fireTableDataChanged();
    }

    public void setClientes(List<Cliente> nuevosClientes) {
        this.clientes.clear();
        
        if (nuevosClientes != null) {
            for (Cliente c : nuevosClientes) {
                this.clientes.add(clonarCliente(c));
            }
        }
        
        fireTableDataChanged();
        System.out.println("Modelo actualizado con " + this.clientes.size() + " clientes");
    }

    public void agregarCliente(Cliente cliente) {
        this.clientes.add(cliente);
        fireTableRowsInserted(clientes.size() - 1, clientes.size() - 1);
    }

    public Cliente clonarCliente(Cliente original) {
        if (original == null) {
            return null;
        }
        
        Cliente copia = new Cliente();
        copia.setIdCliente(original.getIdCliente());
        copia.setNombreCliente(original.getNombreCliente());
        copia.setTelefono(original.getTelefono());
        copia.setCorreo(original.getCorreo());
        return copia;
    }

    public void actualizarDatosCompletos(List<Cliente> nuevosDatos) {
        this.clientes.clear();
        this.clientesOriginales.clear();
        
        if (nuevosDatos != null) {
            for (Cliente c : nuevosDatos) {
                Cliente copia = clonarCliente(c);
                this.clientes.add(copia);
                this.clientesOriginales.add(clonarCliente(copia));
            }
        }
        
        fireTableDataChanged();
    }

    public void setClientesFiltrados(List<Cliente> filtrados, Integer idFiltrado) {
        List<Cliente> copiaFiltrados = new ArrayList<>();
        for (Cliente c : filtrados) {
            copiaFiltrados.add(clonarCliente(c));
        }

        this.clienteFiltradoId = idFiltrado;
        this.clientes = copiaFiltrados;
        fireTableDataChanged();
    }

    @Override
    public void setValueAt(Object value, int row, int column) {
        Cliente cli = clientes.get(row);
        String valor = (value != null) ? value.toString().trim() : "";

        try {
            switch (column) {
                case 1: // Nombre
                    if (valor.isEmpty()) {
                        throw new IllegalArgumentException("El nombre no puede estar vacío");
                    }
                    if (!valor.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
                        throw new IllegalArgumentException("El nombre solo puede contener letras y espacios");
                    }
                    cli.setNombreCliente(valor);
                    break;
                    
                case 2: // Teléfono
                    if (valor.isEmpty()) {
                        throw new IllegalArgumentException("El teléfono no puede estar vacío");
                    }
                    if (!valor.matches("\\d{9,15}")) {
                        throw new IllegalArgumentException("El teléfono debe contener entre 9 y 15 dígitos");
                    }
                    cli.setTelefono(valor);
                    break;
                    
                case 3: // Correo
                    if (valor.isEmpty()) {
                        throw new IllegalArgumentException("El correo no puede estar vacío");
                    }
                    if (!valor.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                        throw new IllegalArgumentException("Formato de correo inválido (ejemplo@dominio.com)");
                    }
                    cli.setCorreo(valor);
                    break;
                    
                default:
                    return;
            }
            
            fireTableCellUpdated(row, column);
            
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(
                null,
                e.getMessage(),
                "Error de validación",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void setValueForClient(Cliente cli, int column, Object value) {
        String valorAnterior = null;
        switch (column) {
            case 1:
                valorAnterior = cli.getNombreCliente();
                if (!Objects.equals(value, valorAnterior)) {
                    cli.setNombreCliente(value.toString());
                }
                break;
            case 2:
                valorAnterior = cli.getTelefono();
                if (!Objects.equals(value, valorAnterior)) {
                    cli.setTelefono(value.toString());
                }
                break;
            case 3:
                valorAnterior = cli.getCorreo();
                if (!Objects.equals(value, valorAnterior)) {
                    cli.setCorreo(value.toString());
                }
                break;
        }
    }
}
