/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Biani
 */
public class AsistenciaTableModel extends AbstractTableModel {

    private List<Asistencia> listaAsistencias;

    private final String[] columnas = {"ID Empleado", "Nombre", "Fecha", "Hora Entrada", "Estado Entrada", "Hora Salida", "Estado Salida"};

//    public AsistenciaTableModel() {
//        listaAsistencias = new ArrayList<>();
//    }
    public AsistenciaTableModel(List<Asistencia> asistencias) {
        this.listaAsistencias = asistencias;
    }

    public void agregarAsistencia(Asistencia asistencia) {
        listaAsistencias.add(asistencia);
        fireTableRowsInserted(listaAsistencias.size() - 1, listaAsistencias.size() - 1);
    }

    @Override
    public int getRowCount() {
        return listaAsistencias.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Asistencia a = listaAsistencias.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return a.getIdEmpleado() != null ? a.getIdEmpleado().getIdEmpleado() : null;
            case 1:
                return a.getIdEmpleado() != null ? a.getIdEmpleado().getNombreEmpleado() : null;
            case 2:
                if (a.getFecha() != null) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    return sdf.format(a.getFecha());
                } else {
                    return "";
                }
            case 3: // Hora Entrada
                if (a.getHoraEntrada() != null) {
                    return new SimpleDateFormat("HH:mm").format(a.getHoraEntrada());
                } else {
                    return "";
                }
            case 4:
                return a.getEstadoEntrada() != null ? a.getEstadoEntrada() : "";
            case 5: // Hora Salida
                if (a.getHoraSalida() != null) {
                    return new SimpleDateFormat("HH:mm").format(a.getHoraSalida());
                } else {
                    return "";
                }
            case 6: // Estado Salida
                return a.getEstadoSalida() != null ? a.getEstadoSalida() : "";

            default:
                return null;
        }
    }

    public void limpiarAsistencias() {
        listaAsistencias.clear();
        fireTableDataChanged();
    }

    public Asistencia getAsistenciaEnFila(int fila) {
        if (fila >= 0 && fila < listaAsistencias.size()) {
            return listaAsistencias.get(fila);
        }
        return null;
    }

    public List<Asistencia> getListaAsistencias() {
        return listaAsistencias;
    }

    public Asistencia buscarAsistenciaPorEmpleado(Empleado empleado) {
        for (Asistencia a : listaAsistencias) {
            if (a.getIdEmpleado() != null && a.getIdEmpleado().getIdEmpleado().equals(empleado.getIdEmpleado())) {
                return a;
            }
        }
        return null;
    }

    public Asistencia getAsistenciaAt(int rowIndex) {
        if (rowIndex >= 0 && rowIndex < listaAsistencias.size()) {
            return listaAsistencias.get(rowIndex);
        }
        return null;
    }

    public void actualizarAsistencia(Asistencia asistenciaActualizada) {
        for (int i = 0; i < listaAsistencias.size(); i++) {
            Asistencia a = listaAsistencias.get(i);
            if (a.getIdAsistencia().equals(asistenciaActualizada.getIdAsistencia())) {
                listaAsistencias.set(i, asistenciaActualizada); 
                fireTableRowsUpdated(i, i); 
                break;
            }
        }
    }
    
    public void setAsistencias(List<Asistencia> asistencias) {
    this.listaAsistencias = asistencias;
    fireTableDataChanged(); 
}


}
