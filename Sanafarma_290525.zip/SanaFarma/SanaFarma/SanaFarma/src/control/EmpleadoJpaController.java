/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import control.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Usuario;
import modelo.Asistencia;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import modelo.Empleado;

/**
 *
 * @author Biani
 */
public class EmpleadoJpaController implements Serializable {

    private EntityManagerFactory emf;

    public EmpleadoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Empleado empleado) throws Exception {
        if (empleado.getAsistenciaList() == null) {
            empleado.setAsistenciaList(new ArrayList<>());
        }

        // VALIDACIÓN: ¿Ya existe un empleado con el mismo nombre?
        if (empleadoExistePorNombre(empleado.getNombreEmpleado())) {
            throw new IllegalArgumentException("Ya existe un empleado con el nombre: " + empleado.getNombreEmpleado());
        }

        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            Usuario idUsuario = empleado.getIdUsuario();
            if (idUsuario != null) {
                idUsuario = em.getReference(idUsuario.getClass(), idUsuario.getIdUsuario());
                empleado.setIdUsuario(idUsuario);
            }

            List<Asistencia> attachedAsistenciaList = new ArrayList<>();
            for (Asistencia a : empleado.getAsistenciaList()) {
                a = em.getReference(a.getClass(), a.getIdAsistencia());
                attachedAsistenciaList.add(a);
            }
            empleado.setAsistenciaList(attachedAsistenciaList);

            em.persist(empleado);

            if (idUsuario != null) {
                Empleado oldEmpleado = idUsuario.getEmpleado();
                if (oldEmpleado != null) {
                    oldEmpleado.setIdUsuario(null);
                    em.merge(oldEmpleado);
                }
                idUsuario.setEmpleado(empleado);
                em.merge(idUsuario);
            }

            for (Asistencia a : empleado.getAsistenciaList()) {
                Empleado oldEmp = a.getIdEmpleado();
                a.setIdEmpleado(empleado);
                em.merge(a);

                if (oldEmp != null) {
                    oldEmp.getAsistenciaList().remove(a);
                    em.merge(oldEmp);
                }
            }

            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void edit(Empleado empleado) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            Empleado persistente = em.find(Empleado.class, empleado.getIdEmpleado());
            if (persistente == null) {
                throw new NonexistentEntityException("El empleado con ID " + empleado.getIdEmpleado() + " no existe.");
            }

            Usuario idUsuarioOld = persistente.getIdUsuario();
            Usuario idUsuarioNew = empleado.getIdUsuario();
            List<Asistencia> asistenciaOld = persistente.getAsistenciaList();
            List<Asistencia> asistenciaNew = empleado.getAsistenciaList();
            if (asistenciaNew == null) {
                asistenciaNew = new ArrayList<>();
            }

            if (idUsuarioNew != null) {
                idUsuarioNew = em.getReference(idUsuarioNew.getClass(), idUsuarioNew.getIdUsuario());
                empleado.setIdUsuario(idUsuarioNew);
            }

            List<Asistencia> attachedAsistenciaNew = new ArrayList<>();
            for (Asistencia a : asistenciaNew) {
                a = em.getReference(a.getClass(), a.getIdAsistencia());
                attachedAsistenciaNew.add(a);
            }
            empleado.setAsistenciaList(attachedAsistenciaNew);

            empleado = em.merge(empleado);

            if (idUsuarioOld != null && !idUsuarioOld.equals(idUsuarioNew)) {
                idUsuarioOld.setEmpleado(null);
                em.merge(idUsuarioOld);
            }

            if (idUsuarioNew != null && !idUsuarioNew.equals(idUsuarioOld)) {
                Empleado oldEmp = idUsuarioNew.getEmpleado();
                if (oldEmp != null) {
                    oldEmp.setIdUsuario(null);
                    em.merge(oldEmp);
                }
                idUsuarioNew.setEmpleado(empleado);
                em.merge(idUsuarioNew);
            }

            for (Asistencia a : asistenciaOld) {
                if (!attachedAsistenciaNew.contains(a)) {
                    a.setIdEmpleado(null);
                    em.merge(a);
                }
            }

            for (Asistencia a : attachedAsistenciaNew) {
                if (!asistenciaOld.contains(a)) {
                    Empleado oldEmp = a.getIdEmpleado();
                    a.setIdEmpleado(empleado);
                    em.merge(a);
                    if (oldEmp != null && !oldEmp.equals(empleado)) {
                        oldEmp.getAsistenciaList().remove(a);
                        em.merge(oldEmp);
                    }
                }
            }

            em.getTransaction().commit();
            System.out.println("Cambios confirmados en la base de datos");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            Empleado empleado = em.find(Empleado.class, id);
            if (empleado == null) {
                throw new NonexistentEntityException("El empleado con ID " + id + " no existe.");
            }

            Usuario idUsuario = empleado.getIdUsuario();
            if (idUsuario != null) {
                idUsuario.setEmpleado(null);
                em.merge(idUsuario);
            }

            for (Asistencia a : empleado.getAsistenciaList()) {
                a.setIdEmpleado(null);
                em.merge(a);
            }

            em.remove(empleado);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public Empleado findEmpleado(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Empleado.class, id);
        } finally {
            em.close();
        }
    }
    
    public List<Empleado> buscarPorNombre(String nombre) {
    EntityManager em = getEntityManager();
    try {
        TypedQuery<Empleado> query = em.createQuery(
            "SELECT e FROM Empleado e WHERE LOWER(e.nombreEmpleado) LIKE :nombre", Empleado.class);
        query.setParameter("nombre", "%" + nombre.toLowerCase() + "%");
        return query.getResultList();
    } finally {
        em.close();
    }
}

    public List<Empleado> findEmpleadoEntities() {
        return findEmpleadoEntities(true, -1, -1);
    }

    public List<Empleado> findEmpleadoEntities(int maxResults, int firstResult) {
        return findEmpleadoEntities(false, maxResults, firstResult);
    }

    private List<Empleado> findEmpleadoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Empleado.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public int getEmpleadoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Empleado> rt = cq.from(Empleado.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    public boolean empleadoExistePorNombre(String nombreEmpleado) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Long> q = em.createQuery(
                "SELECT COUNT(e) FROM Empleado e WHERE e.nombreEmpleado = :nombre", Long.class);
            q.setParameter("nombre", nombreEmpleado);
            return q.getSingleResult() > 0;
        } finally {
            em.close();
        }
    }
}
