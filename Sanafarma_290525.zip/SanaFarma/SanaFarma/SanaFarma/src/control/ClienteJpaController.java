/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import control.exceptions.NonexistentEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Cliente;

/**
 *
 * @author Biani
 */
import java.io.Serializable;
import java.util.List;
import javax.persistence.*;

public class ClienteJpaController implements Serializable {

    private EntityManagerFactory emf;

    public ClienteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cliente cliente) throws Exception {
        validarCliente(cliente);

        if (clienteExistePorNombre(cliente.getNombreCliente())) {
            throw new IllegalArgumentException("Ya existe un cliente con el nombre: " + cliente.getNombreCliente());
        }

        if (clienteExistePorTelefono(cliente.getTelefono())) {
            throw new IllegalArgumentException("Ya existe un cliente con el teléfono: " + cliente.getTelefono());
        }

        if (clienteExistePorCorreo(cliente.getCorreo())) {
            throw new IllegalArgumentException("Ya existe un cliente con el correo: " + cliente.getCorreo());
        }

        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void edit(Cliente cliente) throws Exception {
        validarCliente(cliente);

        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();

            Cliente persistente = em.find(Cliente.class, cliente.getIdCliente());
            if (persistente == null) {
                throw new NonexistentEntityException("El cliente con ID " + cliente.getIdCliente() + " no existe.");
            }

            // Evitar duplicados en nombre, teléfono y correo (excepto el mismo cliente)
            if (!cliente.getNombreCliente().equalsIgnoreCase(persistente.getNombreCliente())
                    && clienteExistePorNombre(cliente.getNombreCliente())) {
                throw new IllegalArgumentException("Ya existe un cliente con el nombre: " + cliente.getNombreCliente());
            }

            if (!cliente.getTelefono().equalsIgnoreCase(persistente.getTelefono())
                    && clienteExistePorTelefono(cliente.getTelefono())) {
                throw new IllegalArgumentException("Ya existe un cliente con el teléfono: " + cliente.getTelefono());
            }

            if (!cliente.getCorreo().equalsIgnoreCase(persistente.getCorreo())
                    && clienteExistePorCorreo(cliente.getCorreo())) {
                throw new IllegalArgumentException("Ya existe un cliente con el correo: " + cliente.getCorreo());
            }

            em.merge(cliente);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            Cliente cliente = em.find(Cliente.class, id);
            if (cliente == null) {
                throw new NonexistentEntityException("El cliente con ID " + id + " no existe.");
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public Cliente findCliente(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    public List<Cliente> buscarPorNombre(String nombre) {
    EntityManager em = getEntityManager();
    try {
        return em.createQuery("SELECT c FROM Cliente c WHERE LOWER(c.nombreCliente) LIKE :nombre", Cliente.class)
                 .setParameter("nombre", "%" + nombre.toLowerCase() + "%")
                 .getResultList();
    } finally {
        em.close();
    }
}


    public List<Cliente> findClienteEntities() {
        return findClienteEntities(true, -1, -1);
    }

    public List<Cliente> findClienteEntities(int maxResults, int firstResult) {
        return findClienteEntities(false, maxResults, firstResult);
    }

    private List<Cliente> findClienteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cliente.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public int getClienteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cliente> rt = cq.from(Cliente.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    // Validaciones específicas
    public boolean clienteExistePorNombre(String nombre) {
    EntityManager em = getEntityManager();
    try {
        TypedQuery<Long> q = em.createQuery(
            "SELECT COUNT(c) FROM Cliente c WHERE LOWER(c.nombreCliente) = :nombre", Long.class);
        q.setParameter("nombre", nombre.toLowerCase());
        return q.getSingleResult() > 0;
    } finally {
        em.close();
    }
}

    public boolean clienteExistePorTelefono(String telefono) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Long> q = em.createQuery(
                "SELECT COUNT(c) FROM Cliente c WHERE c.telefono = :telefono", Long.class);
            q.setParameter("telefono", telefono);
            return q.getSingleResult() > 0;
        } finally {
            em.close();
        }
    }

    public boolean clienteExistePorCorreo(String correo) {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Long> q = em.createQuery(
                "SELECT COUNT(c) FROM Cliente c WHERE LOWER(c.correo) = :correo", Long.class);
            q.setParameter("correo", correo.toLowerCase());
            return q.getSingleResult() > 0;
        } finally {
            em.close();
        }
    }

    private void validarCliente(Cliente cliente) {
        if (cliente.getNombreCliente() == null || cliente.getNombreCliente().trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente no puede estar vacío.");
        }

        if (cliente.getTelefono() == null || cliente.getTelefono().trim().isEmpty()) {
            throw new IllegalArgumentException("El teléfono del cliente no puede estar vacío.");
        }

        if (cliente.getCorreo() == null || cliente.getCorreo().trim().isEmpty()) {
            throw new IllegalArgumentException("El correo del cliente no puede estar vacío.");
        }
    }
}
