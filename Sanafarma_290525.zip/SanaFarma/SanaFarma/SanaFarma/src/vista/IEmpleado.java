/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package vista;

import control.EmpleadoJpaController;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Empleado;
import modelo.EmpleadoTableModel;

/**
 *
 * @author Biani
 */
public class IEmpleado extends javax.swing.JDialog {

    private boolean modoEdicion = false;
    private EmpleadoTableModel modeloTabla;
    private EmpleadoJpaController empleadoJpaController;
    //private JTable tablaEmpleados;
    private Empleado empleadoSeleccionado;
    private JComboBox<Empleado> comboEmpleados;
    private List<Empleado> listaEmpleados = new ArrayList<>();
    private Map<String, Empleado> mapaEmpleados = new HashMap<>();

    public IEmpleado(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        try {
            initComponents();

            EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
            empleadoJpaController = new EmpleadoJpaController(emf);

            listaEmpleados = new ArrayList<>();
            mapaEmpleados = new HashMap<>();
            modeloTabla = new EmpleadoTableModel(new ArrayList<>(), empleadoJpaController);
            tablaEmpleados.setModel(modeloTabla);

            //Hanilitar botones
            deshabilitarCampos();
            ComboBoxEmpleados.removeAllItems();
            ComboBoxEmpleados.insertItemAt("Selecciona un empleado", 0);
            ComboBoxEmpleados.setSelectedIndex(0);
            btnEditar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnGuardarCambios.setEnabled(false);

            cargarDatosIniciales();
            cargarEmpleadosEnCombo();
             configurarValidaciones();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al inicializar: " + e.getMessage(),
                    "Error crítico",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            dispose(); // Cerrar la ventana si hay error 
        }
    }

    private void cargarDatosIniciales() {
        try {
            //Verificacion de que el controlador JPA esté inicializado
            if (empleadoJpaController == null) {
                throw new IllegalStateException("Controlador JPA no inicializado");
            }

            //Obtencion de datos desde la BD
            listaEmpleados = empleadoJpaController.findEmpleadoEntities();

            //Verificacion y actualizacion de modelo
            if (modeloTabla == null) {
                modeloTabla = new EmpleadoTableModel(listaEmpleados, empleadoJpaController);
                tablaEmpleados.setModel(modeloTabla);
            } else {
                modeloTabla.setEmpleados(listaEmpleados);
                
            }

            //Actualizacion del mapa de empleados
            if (mapaEmpleados == null) {
                mapaEmpleados = new HashMap<>();
            }
            actualizarMapaEmpleados();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar datos: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();

            //Verificar listas no nulas
            listaEmpleados = listaEmpleados != null ? listaEmpleados : new ArrayList<>();
            if (modeloTabla != null) {
                modeloTabla.setEmpleados(listaEmpleados);
            }
        }
    }

    private void actualizarMapaEmpleados() {
    mapaEmpleados = new HashMap<>(); //Se tiene que reinicar el mapa de empleados 
    
    if (listaEmpleados != null) {
        for (Empleado emp : listaEmpleados) {
            if (emp != null && emp.getNombreEmpleado() != null) {
                mapaEmpleados.put(emp.getNombreEmpleado().toLowerCase(), emp);
                mapaEmpleados.put(emp.getIdEmpleado().toString(), emp);
            }
        }
    }
}

    private void deshabilitarCampos() {
        txtNombre.setEnabled(false);
        txtPuesto.setEnabled(false);
        txtHorario.setEnabled(false);
        txtUsuario.setEnabled(false);
        btnAceptarRegistro.setEnabled(false);
    }

    private void cargarEmpleadosEnCombo() {
    try {
        //Guardar la seleccion del empleado
        String seleccionActual = (ComboBoxEmpleados.getSelectedIndex() > 0) 
                              ? ComboBoxEmpleados.getSelectedItem().toString()
                              : null;

        //limpiar cComboBox
        ComboBoxEmpleados.removeAllItems();
        ComboBoxEmpleados.addItem("Selecciona un empleado");

        // Obtener empleados desde la BD
        listaEmpleados = empleadoJpaController.findEmpleadoEntities();
        actualizarMapaEmpleados();

        //Llenado del ComboBox
        for (Empleado emp : listaEmpleados) {
            if (emp.getNombreEmpleado() != null && !emp.getNombreEmpleado().trim().isEmpty()) {
                String nombre = emp.getNombreEmpleado().trim();
                ComboBoxEmpleados.addItem(nombre);
                // Actualizar mapa
                mapaEmpleados.put(nombre.toLowerCase(), emp);
                mapaEmpleados.put(emp.getIdEmpleado().toString(), emp);
            }
        }

        if (seleccionActual != null) {
            for (int i = 1; i < ComboBoxEmpleados.getItemCount(); i++) {
                if (ComboBoxEmpleados.getItemAt(i).equals(seleccionActual)) {
                    ComboBoxEmpleados.setSelectedIndex(i);
                    return;
                }
            }
        }

        //Mostrar encabezado inicial
        ComboBoxEmpleados.setSelectedIndex(0);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al actualizar lista de empleados: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

    private void limpiarCampos() {
        txtNombre.setText("");
        txtPuesto.setText("");
        txtHorario.setText("");
        txtUsuario.setText("");
    }

    private void actualizarVista() {
        if (modeloTabla != null) {
            modeloTabla.notificarCambios();
        }
    }

    private void mostrarEmpleadoEnTabla(Empleado empleado) {
    // Limpiar seleccion
    tablaEmpleados.clearSelection();
    
    //Crear una lista temporal
    List<Empleado> listaTemporal = new ArrayList<>();
    
    Empleado copia = new Empleado();
    copia.setIdEmpleado(empleado.getIdEmpleado());
    copia.setNombreEmpleado(empleado.getNombreEmpleado());
    copia.setPuesto(empleado.getPuesto());
    copia.setHorario(empleado.getHorario());
    
    listaTemporal.add(copia);
    
    //Actualizacion del modelo de la tabla
    modeloTabla.setEmpleados(listaTemporal);
    
    //Seleccion del empleado y mostrar
    if (tablaEmpleados.getRowCount() > 0) {
        tablaEmpleados.setRowSelectionInterval(0, 0);
        tablaEmpleados.scrollRectToVisible(tablaEmpleados.getCellRect(0, 0, true));
    }
}
    
    private void actualizarTablaConNuevoEmpleado(Empleado nuevoEmpleado) {
        if (modeloTabla != null) {
            modeloTabla.agregarEmpleado(nuevoEmpleado);
        } else {
            //recargar la tabla en caso de ser nulo
            cargarDatosIniciales();
        }

        //SEleccion del nuevo empleado en la tabla
        int rowIndex = listaEmpleados.indexOf(nuevoEmpleado);
        if (rowIndex >= 0) {
            tablaEmpleados.setRowSelectionInterval(rowIndex, rowIndex);
            tablaEmpleados.scrollRectToVisible(tablaEmpleados.getCellRect(rowIndex, 0, true));
        }
    }

    private void actualizarComboBoxDespuesDeRegistro(Empleado nuevoEmpleado) {
        //Se guarda el estado actual del ComboBox
        Object seleccionActual = ComboBoxEmpleados.getSelectedItem();
        int indiceSeleccionado = ComboBoxEmpleados.getSelectedIndex();

        //lImpiar combo
        ComboBoxEmpleados.removeAllItems();
        ComboBoxEmpleados.addItem("Selecciona un empleado");

        //Agregar empleados al combo
        for (Empleado emp : listaEmpleados) {
            ComboBoxEmpleados.addItem(emp.getNombreEmpleado());
        }

        //Limpiar combo
        ComboBoxEmpleados.setSelectedIndex(0);
    }
    
   
   private void refrescarDatosCompletamente() {
    try {
        List<Empleado> empleadosActuales = empleadoJpaController.findEmpleadoEntities();
        modeloTabla.actualizarDatosCompletos(empleadosActuales);
        listaEmpleados = new ArrayList<>(empleadosActuales);
        cargarEmpleadosEnCombo(); 
        System.out.println("Datos refrescados completamente");

    } catch (Exception e) {
        e.printStackTrace();
        throw new RuntimeException("Error al refrescar datos", e);
    }
}

    
    private void restaurarEstadoCompleto() {
    try {
        // Obtener datos de empleado
        List<Empleado> empleadosActuales = empleadoJpaController.findEmpleadoEntities();
        
        //Limpiar modelo
        modeloTabla.resetFilter();
        modeloTabla.actualizarDatosCompletos(empleadosActuales);
        
        //Actualizar datos
        listaEmpleados = new ArrayList<>(empleadosActuales);
        actualizarMapaEmpleados();
        
        //Limpiar la seleccion
        empleadoSeleccionado = null;
        tablaEmpleados.clearSelection();
        ComboBoxEmpleados.setSelectedIndex(0);
        
        //Actualizar modelo de la tabla
        modeloTabla.fireTableDataChanged();
        tablaEmpleados.repaint();
        
        System.out.println("Estado completamente restaurado. Mostrando " + 
                         modeloTabla.getRowCount() + " empleados.");
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al restaurar estado: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
    
    private void configurarValidaciones() {
    txtNombre.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
            if (!(Character.isLetter(c) || c == KeyEvent.VK_SPACE || c == KeyEvent.VK_BACK_SPACE || 
                "áéíóúÁÉÍÓÚñÑ".indexOf(c) >= 0)) {
                e.consume();
                Toolkit.getDefaultToolkit().beep();
            }
        }
    });

    txtUsuario.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
            if (!(Character.isLetter(c) || c == KeyEvent.VK_BACK_SPACE || 
                "áéíóúÁÉÍÓÚñÑ".indexOf(c) >= 0)) {
                e.consume();
                Toolkit.getDefaultToolkit().beep();
            }
        }
    });

    txtPuesto.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
            if (!(Character.isLetter(c) || c == KeyEvent.VK_BACK_SPACE || 
                  "áéíóúÁÉÍÓÚñÑ".indexOf(c) >= 0)) {
                e.consume();
                Toolkit.getDefaultToolkit().beep();
            }
        }
    });

    txtHorario.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            String textoActual = txtHorario.getText();
            char c = e.getKeyChar();
            int posicion = txtHorario.getCaretPosition();
            
            if (c == KeyEvent.VK_BACK_SPACE) return;
            
            if (posicion < 2) { 
                if (!Character.isDigit(c)) {
                    e.consume();
                    return;
                }
                if (posicion == 0 && c > '2') { 
                    e.consume();
                    return;
                }
                if (posicion == 1 && textoActual.length() > 0 && textoActual.charAt(0) == '2' && c > '3') {
                    e.consume(); 
                    return;
                }
            } 
            else if (posicion == 2) { 
                if (c != ':') {
                    e.consume();
                    return;
                }
            }
            else if (posicion < 5) { 
                if (!Character.isDigit(c)) {
                    e.consume();
                    return;
                }
                if (posicion == 3 && c > '5') {
                    e.consume();
                    return;
                }
            }
            else if (posicion == 5) { 
                if (c != '-') {
                    e.consume();
                    return;
                }
            }
            else if (posicion < 8) { 
                if (!Character.isDigit(c)) {
                    e.consume();
                    return;
                }
                if (posicion == 6 && c > '2') {
                    e.consume();
                    return;
                }
                if (posicion == 7 && textoActual.length() > 6 && textoActual.charAt(6) == '2' && c > '3') {
                    e.consume();
                    return;
                }
            }
            else if (posicion == 8) { 
                if (c != ':') {
                    e.consume();
                    return;
                }
            }
            else if (posicion < 11) { 
                if (!Character.isDigit(c)) {
                    e.consume();
                    return;
                }
                if (posicion == 9 && c > '5') {
                    e.consume();
                    return;
                }
            }
            else { 
                e.consume();
            }
        }
    });
}
    
   private boolean validarCampos() {
    // Validar que ningún campo esté vacío
    if (txtNombre.getText().trim().isEmpty()) {
        mostrarError("Campo vacío", "El nombre es obligatorio");
        txtNombre.requestFocus();
        return false;
    }
    
    if (txtPuesto.getText().trim().isEmpty()) {
        mostrarError("Campo vacío", "El puesto es obligatorio");
        txtPuesto.requestFocus();
        return false;
    }
    
    if (txtUsuario.getText().trim().isEmpty()) {
        mostrarError("Campo vacío", "El tipo de usuario es obligatorio");
        txtUsuario.requestFocus();
        return false;
    }
    
    if (txtHorario.getText().trim().isEmpty()) {
        mostrarError("Campo vacío", "El horario es obligatorio");
        txtHorario.requestFocus();
        return false;
    }

    // Validar nombre 
    if (!txtNombre.getText().matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
        mostrarError("Nombre inválido", "Solo puede contener letras y espacios");
        txtNombre.requestFocus();
        return false;
    }

    // Validar puesto 
    if (!txtPuesto.getText().matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ]+")) {
        mostrarError("Puesto inválido", "Solo puede contener letras (sin espacios)");
        txtPuesto.requestFocus();
        return false;
    }

    // Validar usuario 
    String usuario = txtUsuario.getText().toLowerCase();
    if (!usuario.equals("empleado") && !usuario.equals("administrador")) {
        mostrarError("Usuario inválido", "Solo se permiten los valores: 'empleado' o 'administrador'");
        txtUsuario.requestFocus();
        return false;
    }

    // Validar horario 
    if (!txtHorario.getText().matches("^([01]?[0-9]|2[0-3]):[0-5][0-9]-([01]?[0-9]|2[0-3]):[0-5][0-9]$")) {
        mostrarError("Horario inválido", "Formato debe ser HH:MM-HH:MM (ej. 08:00-16:00)");
        txtHorario.requestFocus();
        return false;
    }

    return true;
}



private void mostrarError(String titulo, String mensaje) {
    JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnRegistrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        LabelNombre = new javax.swing.JLabel();
        LabelPuesto = new javax.swing.JLabel();
        LabelHorario = new javax.swing.JLabel();
        LabelUsuario = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        txtHorario = new javax.swing.JTextField();
        txtUsuario = new javax.swing.JTextField();
        btnAceptarRegistro = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        ComboBoxEmpleados = new javax.swing.JComboBox<>();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnGuardarCambios = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btnRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/agregar.png"))); // NOI18N
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 153, 255));
        jLabel1.setText("EMPLEADO");

        LabelNombre.setText("Nombre");

        LabelPuesto.setText("Puesto");

        LabelHorario.setText("Horario");

        LabelUsuario.setText("Usuario");

        txtHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorarioActionPerformed(evt);
            }
        });

        btnAceptarRegistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/aceptar.png"))); // NOI18N
        btnAceptarRegistro.setText("Aceptar");
        btnAceptarRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarRegistroActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Tabla Empleados");

        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaEmpleados);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Empleados");

        ComboBoxEmpleados.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editar.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscarProveedor.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cancelar.png"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnGuardarCambios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/aceptar.png"))); // NOI18N
        btnGuardarCambios.setText("Guardar Cambios");
        btnGuardarCambios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarCambiosActionPerformed(evt);
            }
        });

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/regresar.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 977, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(110, 110, 110)
                                        .addComponent(LabelNombre))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(113, 113, 113)
                                .addComponent(LabelPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(112, 112, 112)
                                .addComponent(LabelHorario))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(110, 110, 110)
                                .addComponent(LabelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(274, 274, 274)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(176, 176, 176)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(188, 188, 188)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(ComboBoxEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(281, 281, 281)
                        .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btnGuardarCambios)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(431, 431, 431)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(btnAceptarRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LabelNombre)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8)
                                .addComponent(LabelPuesto))
                            .addComponent(ComboBoxEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(LabelHorario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(LabelUsuario)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAceptarRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarCambios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRegresar))
                .addGap(44, 44, 44))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        // TODO add your handling code here:
        
        txtNombre.setEnabled(true);
        txtPuesto.setEnabled(true);
        txtHorario.setEnabled(true);
        txtUsuario.setEnabled(true);
        btnAceptarRegistro.setEnabled(true);

        ComboBoxEmpleados.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnEditar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnGuardarCambios.setEnabled(false);
        btnCancelar.setEnabled(true);

    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnAceptarRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarRegistroActionPerformed
        if (!validarCampos()) {
        return;
    }
    
        try {
            String nombre = txtNombre.getText().trim();
            String puesto = txtPuesto.getText().trim();
            String horario = txtHorario.getText().trim();

            // Validaciones
            if (nombre.isEmpty() || puesto.isEmpty() || horario.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.");
                limpiarCampos();
                return;
            }

            List<Empleado> existentes = empleadoJpaController.buscarPorNombre(nombre);
            if (!existentes.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ya existe un empleado con ese nombre.");
                limpiarCampos();
                return;
            }

            // Crear nuevo empleado
            Empleado nuevo = new Empleado();
            nuevo.setNombreEmpleado(nombre);
            nuevo.setPuesto(puesto);
            nuevo.setHorario(horario);

            //Crear desde la base de datos
            empleadoJpaController.create(nuevo);

            //actualizacion de los datos
            listaEmpleados.add(nuevo);
            if (mapaEmpleados != null) {
                mapaEmpleados.put(nuevo.getNombreEmpleado().toLowerCase(), nuevo);
            }

            //actualizacion de combo
            actualizarComboBoxDespuesDeRegistro(nuevo);

            // actualizacion de tabla
            actualizarTablaConNuevoEmpleado(nuevo);

            JOptionPane.showMessageDialog(this, "Empleado registrado correctamente.");

            //limpiar componentes
            limpiarCampos();
            limpiarCampos();
            txtNombre.setEnabled(false);
            txtPuesto.setEnabled(false);
            txtHorario.setEnabled(false);
            txtUsuario.setEnabled(false);
            ComboBoxEmpleados.setEnabled(true);
            btnBuscar.setEnabled(true);
            btnAceptarRegistro.setEnabled(false);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al registrar empleado: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnAceptarRegistroActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        try {
        //Validar selección
        if (ComboBoxEmpleados.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this,
                "Por favor seleccione un empleado válido",
                "Selección inválida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        //limpiar la seleccion
        empleadoSeleccionado = null;
        tablaEmpleados.clearSelection();
        
        //obtencion del empleado seleccionado
        String nombreSeleccionado = ComboBoxEmpleados.getSelectedItem().toString();
        empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
        
        if (empleadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this,
                "No se encontró el empleado seleccionado",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        //Mostrar empleado en la tabla
        List<Empleado> empleadoUnico = new ArrayList<>();
        empleadoUnico.add(empleadoSeleccionado);
        modeloTabla.setEmpleados(empleadoUnico);
        
        //componentes
        btnEditar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnGuardarCambios.setEnabled(false);
        btnRegistrar.setEnabled(false);
        
        System.out.println("Mostrando empleado: " + empleadoSeleccionado.getNombreEmpleado());
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al buscar empleado: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        try {
        //verificacion de empleado seleccionado
        if (empleadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay ningún empleado seleccionado para editar",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        //confirmacion
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Desea editar los datos del empleado?\n" +
                "Nombre: " + empleadoSeleccionado.getNombreEmpleado() + "\n" +
                "Puesto: " + empleadoSeleccionado.getPuesto() + "\n" +
                "Horario: " + empleadoSeleccionado.getHorario(),
                "Confirmar edición",
                JOptionPane.YES_NO_OPTION);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        //se activa para editar
        modeloTabla.setModoEdicion(true);
        
        // Seleccionar la fila correspondiente
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            if (modeloTabla.getEmpleadoAt(i).getIdEmpleado().equals(empleadoSeleccionado.getIdEmpleado())) {
                tablaEmpleados.setRowSelectionInterval(i, i);
                tablaEmpleados.scrollRectToVisible(tablaEmpleados.getCellRect(i, 1, true));
                tablaEmpleados.editCellAt(i, 1); // Empezar edición en columna Nombre
                break;
            }
        }

        //componentes
        ComboBoxEmpleados.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnGuardarCambios.setEnabled(true);
        btnEditar.setEnabled(false);
        btnRegistrar.setEnabled(false);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
                "Error al iniciar edición: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnGuardarCambiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarCambiosActionPerformed
        try {
        if (tablaEmpleados.isEditing()) {
            tablaEmpleados.getCellEditor().stopCellEditing();
        }

        //obtener empleados modificados
        List<Empleado> modificados = modeloTabla.getEmpleadosModificados();
        
        if (modificados.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No hay cambios para guardar.",
                "Información", 
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        //Guardar cambios en la base de datos
        for (Empleado e : modificados) {
            empleadoJpaController.edit(e);
            System.out.println("Guardando cambios para ID: " + e.getIdEmpleado());
        }

        //Actualizar datos 
        listaEmpleados = empleadoJpaController.findEmpleadoEntities();
        actualizarMapaEmpleados();
        
        //limpiar combobox
        ComboBoxEmpleados.removeAllItems();
        ComboBoxEmpleados.addItem("Selecciona un empleado");
        
        // Ordenar empleados
        listaEmpleados.sort(Comparator.comparing(Empleado::getIdEmpleado));
        
        for (Empleado emp : listaEmpleados) {
            if (emp.getNombreEmpleado() != null && !emp.getNombreEmpleado().trim().isEmpty()) {
                ComboBoxEmpleados.addItem(emp.getNombreEmpleado().trim());
            }
        }
        
        //reinicar combo
        ComboBoxEmpleados.setSelectedIndex(0);
        
        //Actualizar modelo y vista
        modeloTabla.actualizarDatosCompletos(listaEmpleados);
        modeloTabla.setModoEdicion(false);
        
        //componentes
        btnEditar.setEnabled(false);
        btnGuardarCambios.setEnabled(false);
        btnEliminar.setEnabled(false);
        ComboBoxEmpleados.setEnabled(true);
        btnBuscar.setEnabled(true);
        
        JOptionPane.showMessageDialog(this, 
            "Cambios guardados correctamente. El ComboBox ha sido actualizado.",
            "Éxito", 
            JOptionPane.INFORMATION_MESSAGE);
            
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this,
            "Error al guardar cambios: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
    }//GEN-LAST:event_btnGuardarCambiosActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
   // Verificar si hay un empleado seleccionado
    if (ComboBoxEmpleados.getSelectedIndex() <= 0) {
        JOptionPane.showMessageDialog(this, 
            "Por favor seleccione un empleado de la lista",
            "Selección requerida", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Obtener el empleado seleccionado
    String nombreSeleccionado = ComboBoxEmpleados.getSelectedItem().toString();
    Empleado emp = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
    
    if (emp == null) {
        JOptionPane.showMessageDialog(this,
            "No se encontró el empleado seleccionado",
            "Error",
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Confirmacion
    int confirm = JOptionPane.showConfirmDialog(this,
        "¿Estás seguro de eliminar a " + emp.getNombreEmpleado() + "?", 
        "Confirmar eliminación",
        JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {
        try {
            //Eliminar de la base de datos
            empleadoJpaController.destroy(emp.getIdEmpleado());
            
            //Eliminar de las estructuras de datos
            listaEmpleados.removeIf(e -> e.getIdEmpleado().equals(emp.getIdEmpleado()));
            mapaEmpleados.remove(emp.getNombreEmpleado().toLowerCase());
            mapaEmpleados.remove(emp.getIdEmpleado().toString());
            
            //actualizar combo
            cargarEmpleadosEnCombo();
            
            //Actualizar la tabla
            modeloTabla.actualizarDatosCompletos(listaEmpleados);
            
            // componentes
            empleadoSeleccionado = null;
            btnEditar.setEnabled(false);
            btnEliminar.setEnabled(false);
            
            JOptionPane.showMessageDialog(this, 
                emp.getNombreEmpleado() + " ha sido eliminado correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al eliminar: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
 
    if (tablaEmpleados.isEditing()) {
        tablaEmpleados.getCellEditor().stopCellEditing();
    }
    
    //componentes
    restaurarEstadoCompleto();
    ComboBoxEmpleados.setEnabled(true);
    btnBuscar.setEnabled(true);
    btnGuardarCambios.setEnabled(false);
    btnRegistrar.setEnabled(true);
    btnEditar.setEnabled(false);
    btnEliminar.setEnabled(false);
    limpiarCampos();
    txtNombre.setEnabled(false);
    txtPuesto.setEnabled(false);
    txtHorario.setEnabled(false);
    txtUsuario.setEnabled(false);
    btnAceptarRegistro.setEnabled(false);
    
    //confirmación
    JOptionPane.showMessageDialog(this,
        "Operación cancelada. Mostrando lista completa de empleados.",
        "Cancelado",
        JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorarioActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IEmpleado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IEmpleado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IEmpleado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IEmpleado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                IEmpleado dialog = new IEmpleado(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxEmpleados;
    private javax.swing.JLabel LabelHorario;
    private javax.swing.JLabel LabelNombre;
    private javax.swing.JLabel LabelPuesto;
    private javax.swing.JLabel LabelUsuario;
    private javax.swing.JButton btnAceptarRegistro;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarCambios;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaEmpleados;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
