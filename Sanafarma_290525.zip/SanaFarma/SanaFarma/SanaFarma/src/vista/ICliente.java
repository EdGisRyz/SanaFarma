/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package vista;

import control.ClienteJpaController;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Cliente;
import modelo.ClienteTableModel;

/**
 *
 * @author Biani
 */
public class ICliente extends javax.swing.JDialog {

    private boolean modoEdicion = false;
    private ClienteTableModel modeloTabla;
    private ClienteJpaController clienteJpaController;
    private Cliente clienteSeleccionado;
    private JComboBox<Cliente> comboClientes;
    private List<Cliente> listaClientes = new ArrayList<>();
    private Map<String, Cliente> mapaClientes = new HashMap<>();

    public ICliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        try {
            initComponents();

            EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
            clienteJpaController = new ClienteJpaController(emf);

            listaClientes = new ArrayList<>();
            mapaClientes = new HashMap<>();
            modeloTabla = new ClienteTableModel(new ArrayList<>(), clienteJpaController);
            tablaClientes.setModel(modeloTabla); // Asegúrate de tener este JTable con ese nombre

            //componentes
            deshabilitarCampos();
            ComboBoxClientes.removeAllItems();
            ComboBoxClientes.insertItemAt("Selecciona un cliente", 0);
            ComboBoxClientes.setSelectedIndex(0);
            btnEditar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnGuardarCambios.setEnabled(false);

            cargarDatosIniciales();
            cargarClientesEnCombo();
            configurarValidaciones();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al inicializar: " + e.getMessage(),
                    "Error crítico",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            dispose(); // Cerrar la ventana si hay error crítico
        }
    }

    private void cargarDatosIniciales() {
        try {
            // Verificar que el controlador JPA esté inicializado
            if (clienteJpaController == null) {
                throw new IllegalStateException("Controlador JPA no inicializado");
            }

            // Obtener datos de la base de datos
            listaClientes = clienteJpaController.findClienteEntities();

            // Verificar y actualizar tabla
            if (modeloTabla == null) {
                modeloTabla = new ClienteTableModel(listaClientes, clienteJpaController);
                tablaClientes.setModel(modeloTabla);
            } else {
                modeloTabla.setClientes(listaClientes);
            }

            // Actualizar mapa de clientes
            if (mapaClientes == null) {
                mapaClientes = new HashMap<>();
            }
            actualizarMapaClientes();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar datos: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();

            // listas no sean null
            listaClientes = listaClientes != null ? listaClientes : new ArrayList<>();
            if (modeloTabla != null) {
                modeloTabla.setClientes(listaClientes);
            }
        }
    }

    private void actualizarMapaClientes() {
        mapaClientes = new HashMap<>(); // Reiniciar mapa

        if (listaClientes != null) {
            for (Cliente cli : listaClientes) {
                if (cli != null && cli.getNombreCliente() != null) {
                    mapaClientes.put(cli.getNombreCliente().toLowerCase(), cli);
                    mapaClientes.put(cli.getIdCliente().toString(), cli);
                }
            }
        }
    }

    private void deshabilitarCampos() {
        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnAceptarRegistro.setEnabled(false);
    }

    private void cargarClientesEnCombo() {
        try {
            //Guardar selección actual 
            String seleccionActual = (ComboBoxClientes.getSelectedIndex() > 0)
                    ? ComboBoxClientes.getSelectedItem().toString()
                    : null;

            //limpiar ComboBox
            ComboBoxClientes.removeAllItems();
            ComboBoxClientes.addItem("Selecciona un cliente");

            // obtener clientes desde BD 
            listaClientes = clienteJpaController.findClienteEntities();
            actualizarMapaClientes();

            //Llenar ComboBox 
            for (Cliente cli : listaClientes) {
                if (cli.getNombreCliente() != null && !cli.getNombreCliente().trim().isEmpty()) {
                    String nombre = cli.getNombreCliente().trim();
                    ComboBoxClientes.addItem(nombre);
                    // Actualizar mapa
                    mapaClientes.put(nombre.toLowerCase(), cli);
                    mapaClientes.put(cli.getIdCliente().toString(), cli);
                }
            }

            //Restaurar selección 
            if (seleccionActual != null) {
                for (int i = 1; i < ComboBoxClientes.getItemCount(); i++) {
                    if (ComboBoxClientes.getItemAt(i).equals(seleccionActual)) {
                        ComboBoxClientes.setSelectedIndex(i);
                        return;
                    }
                }
            }

            //limpiar combo
            ComboBoxClientes.setSelectedIndex(0);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar lista de clientes: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
    }

    private void actualizarVista() {
        if (modeloTabla != null) {
            modeloTabla.notificarCambios();
        }
    }

    private void mostrarClienteEnTabla(Cliente cliente) {
        //Limpiar selección previa
        tablaClientes.clearSelection();

        //Crear lista temporal con solo este cliente
        List<Cliente> listaTemporal = new ArrayList<>();

        Cliente copia = new Cliente();
        copia.setIdCliente(cliente.getIdCliente());
        copia.setNombreCliente(cliente.getNombreCliente());
        copia.setTelefono(cliente.getTelefono());
        copia.setCorreo(cliente.getCorreo());

        listaTemporal.add(copia);

        //Actualizar modelo
        modeloTabla.setClientes(listaTemporal);

        //Seleccionar y mostrar
        if (tablaClientes.getRowCount() > 0) {
            tablaClientes.setRowSelectionInterval(0, 0);
            tablaClientes.scrollRectToVisible(tablaClientes.getCellRect(0, 0, true));
        }
    }

    private void actualizarTablaConNuevoCliente(Cliente nuevoCliente) {
        if (modeloTabla != null) {
            modeloTabla.agregarCliente(nuevoCliente);
        } else {
            // Si el modelo es null, recargar toda la tabla
            cargarDatosIniciales();
        }

        //Seleccionar el nuevo cliente en la tabla
        int rowIndex = listaClientes.indexOf(nuevoCliente);
        if (rowIndex >= 0) {
            tablaClientes.setRowSelectionInterval(rowIndex, rowIndex);
            tablaClientes.scrollRectToVisible(tablaClientes.getCellRect(rowIndex, 0, true));
        }
    }

    private void actualizarComboBoxDespuesDeRegistro(Cliente nuevoCliente) {
        // Guardar el estado actual del ComboBox
        Object seleccionActual = ComboBoxClientes.getSelectedItem();
        int indiceSeleccionado = ComboBoxClientes.getSelectedIndex();

        // limpiar combo
        ComboBoxClientes.removeAllItems();
        ComboBoxClientes.addItem("Selecciona un cliente");

        // Agregar todos los clientes 
        for (Cliente cli : listaClientes) {
            ComboBoxClientes.addItem(cli.getNombreCliente());
        }

        // limpiar combo
        ComboBoxClientes.setSelectedIndex(0);
    }

    private void refrescarDatosCompletamente() {
        try {
            List<Cliente> clientesActuales = clienteJpaController.findClienteEntities();
            modeloTabla.actualizarDatosCompletos(clientesActuales);
            listaClientes = new ArrayList<>(clientesActuales);
            cargarClientesEnCombo(); // Asume que existe y reemplaza a actualizarMapaClientes()
            System.out.println("Datos refrescados completamente");

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error al refrescar datos", e);
        }
    }

    private void restaurarEstadoCompleto() {
        try {
            //Obtener desde la base de datos
            List<Cliente> clientesActuales = clienteJpaController.findClienteEntities();

            // resetear modelo
            modeloTabla.resetFilter();
            modeloTabla.actualizarDatosCompletos(clientesActuales);

            //actualizar
            listaClientes = new ArrayList<>(clientesActuales);
            actualizarMapaClientes();

            // limpiar combo
            clienteSeleccionado = null;
            tablaClientes.clearSelection();
            ComboBoxClientes.setSelectedIndex(0);

            //Actualizar la vista completa
            modeloTabla.fireTableDataChanged();
            tablaClientes.repaint();

            System.out.println("Estado completamente restaurado. Mostrando "
                    + modeloTabla.getRowCount() + " clientes.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al restaurar estado: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void configurarValidaciones() {
        
        txtNombre.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isLetter(c) || c == KeyEvent.VK_SPACE || c == KeyEvent.VK_BACK_SPACE
                        || "áéíóúÁÉÍÓÚñÑ".indexOf(c) >= 0)) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });

        txtTelefono.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();

                if (!Character.isDigit(c) && c != KeyEvent.VK_BACK_SPACE) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                    return;
                }

                if (txtTelefono.getText().length() >= 10 && c != KeyEvent.VK_BACK_SPACE) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });

        txtCorreo.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                String validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@._-";
                if (!(validChars.indexOf(c) >= 0 || c == KeyEvent.VK_BACK_SPACE)) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    private boolean validarCampos() {
        // Validar que ningún campo esté vacío
        if (txtNombre.getText().trim().isEmpty()) {
            mostrarError("Campo vacío", "El nombre es obligatorio");
            txtNombre.requestFocus();
            limpiarCampos();

        //componentes
        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        if (txtTelefono.getText().trim().isEmpty()) {
            mostrarError("Campo vacío", "El teléfono es obligatorio");
            txtTelefono.requestFocus();
            limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        if (txtCorreo.getText().trim().isEmpty()) {
            mostrarError("Campo vacío", "El correo es obligatorio");
            txtCorreo.requestFocus();
            limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        if (!txtNombre.getText().matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            mostrarError("Nombre inválido", "El nombre solo puede contener letras y espacios");
            txtNombre.requestFocus();
            limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        if (!txtTelefono.getText().matches("\\d{10}")) {
            mostrarError("Teléfono inválido", "El teléfono debe contener exactamente 10 dígitos");
            txtTelefono.requestFocus();
            limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        if (!txtCorreo.getText().matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
            mostrarError("Correo inválido", "Introduce un correo electrónico válido");
            txtCorreo.requestFocus();
            limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
            return false;
        }

        return true; 
    }

    private void mostrarError(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnRegistrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        ComboBoxClientes = new javax.swing.JComboBox<>();
        btnBuscar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        labelNombre = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        labelTelefono = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        labelCorreo = new javax.swing.JLabel();
        btnAceptarRegistro = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClientes = new javax.swing.JTable();
        btnGuardarCambios = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 153, 255));
        jLabel1.setText("CLIENTE");

        btnRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/agregar.png"))); // NOI18N
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Clientes");

        ComboBoxClientes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscarProveedor.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editar.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        labelNombre.setText("Nombre");

        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });

        labelTelefono.setText("Telefono");

        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });

        labelCorreo.setText("Correo");

        btnAceptarRegistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/aceptar.png"))); // NOI18N
        btnAceptarRegistro.setText("Aceptar");
        btnAceptarRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarRegistroActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Lista Clientes");

        tablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaClientes);

        btnGuardarCambios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/aceptar.png"))); // NOI18N
        btnGuardarCambios.setText("Guardar Cambios");
        btnGuardarCambios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarCambiosActionPerformed(evt);
            }
        });

        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cancelar.png"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/regresar.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(labelCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1017, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(108, 108, 108)
                                    .addComponent(labelTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addGap(32, 32, 32)
                                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addContainerGap()
                                            .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(75, 75, 75)
                                    .addComponent(btnAceptarRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(85, 85, 85)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(87, 87, 87)
                                    .addComponent(ComboBoxClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(111, 111, 111)
                            .addComponent(labelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(331, 331, 331)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(190, 190, 190)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(295, 295, 295)
                        .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnGuardarCambios)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(470, 470, 470)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(484, 484, 484)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(53, 53, 53)
                .addComponent(btnRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombre)
                    .addComponent(jLabel2)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelTelefono)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelCorreo))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(btnAceptarRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(36, 36, 36)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarCambios, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefonoActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:

        txtNombre.setEnabled(true);
        txtTelefono.setEnabled(true);
        txtCorreo.setEnabled(true);
        btnAceptarRegistro.setEnabled(true);

        ComboBoxClientes.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnEditar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnGuardarCambios.setEnabled(false);
        btnCancelar.setEnabled(true);

    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnAceptarRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarRegistroActionPerformed
        // TODO add your handling code here:
        if (!validarCampos()) {
    return;
}

try {
    String nombre = txtNombre.getText().trim();
    String telefono = txtTelefono.getText().trim();
    String correo = txtCorreo.getText().trim();

    // Validaciones
    if (nombre.isEmpty() || telefono.isEmpty() || correo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.");
        limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
        return;
    }

    // Verificar si ya existe un cliente con ese nombre
    List<Cliente> existentes = clienteJpaController.buscarPorNombre(nombre);
    if (!existentes.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Ya existe un cliente con ese nombre.");
        limpiarCampos();

        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnAceptarRegistro.setEnabled(false);
        return;
    }

    // Crear nuevo cliente
    Cliente nuevo = new Cliente();
    nuevo.setNombreCliente(nombre);
    nuevo.setTelefono(telefono);
    nuevo.setCorreo(correo);

    //crear en la base de datos
    clienteJpaController.create(nuevo);

    // Actualizar estructuras de datos
    listaClientes.add(nuevo);
    if (mapaClientes != null) {
        mapaClientes.put(nuevo.getNombreCliente().toLowerCase(), nuevo);
    }

    //Actualizar el ComboBox
    actualizarComboBoxDespuesDeRegistro(nuevo);

    //Actualizar la tabla
    actualizarTablaConNuevoCliente(nuevo);

    JOptionPane.showMessageDialog(this, "Cliente registrado correctamente.");

    limpiarCampos();
    txtNombre.setEnabled(false);
    txtTelefono.setEnabled(false);
    txtCorreo.setEnabled(false);
    ComboBoxClientes.setEnabled(true);
    btnBuscar.setEnabled(true);
    btnAceptarRegistro.setEnabled(false);
    btnRegistrar.setEnabled(true);

} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error al registrar cliente: " + e.getMessage());
    e.printStackTrace();
}

    }//GEN-LAST:event_btnAceptarRegistroActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // TODO add your handling code here:
        try {
            // 1. Validar selección
            if (ComboBoxClientes.getSelectedIndex() <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Por favor seleccione un cliente válido",
                        "Selección inválida",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            // limpiar seleccion
            clienteSeleccionado = null;
            tablaClientes.clearSelection();

            //Obtener el nuevo cliente seleccionado
            String nombreSeleccionado = ComboBoxClientes.getSelectedItem().toString();
            clienteSeleccionado = mapaClientes.get(nombreSeleccionado.toLowerCase());

            if (clienteSeleccionado == null) {
                JOptionPane.showMessageDialog(this,
                        "No se encontró el cliente seleccionado",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            //Mostrar el cliente en la tabla
            List<Cliente> clienteUnico = new ArrayList<>();
            clienteUnico.add(clienteSeleccionado);
            modeloTabla.setClientes(clienteUnico);

            btnEditar.setEnabled(true);
            btnEliminar.setEnabled(true);
            btnGuardarCambios.setEnabled(false);
            btnRegistrar.setEnabled(false);

            System.out.println("Mostrando cliente: " + clienteSeleccionado.getNombreCliente());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al buscar cliente: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        try {
            // Verificar cliente seleccionado
            if (clienteSeleccionado == null) {
                JOptionPane.showMessageDialog(this,
                        "No hay ningún cliente seleccionado para editar",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Confirmarcion
            int confirmacion = JOptionPane.showConfirmDialog(this,
                    "¿Desea editar los datos del cliente?\n"
                    + "Nombre: " + clienteSeleccionado.getNombreCliente() + "\n"
                    + "Teléfono: " + clienteSeleccionado.getTelefono() + "\n"
                    + "Correo: " + clienteSeleccionado.getCorreo(),
                    "Confirmar edición",
                    JOptionPane.YES_NO_OPTION);

            if (confirmacion != JOptionPane.YES_OPTION) {
                return;
            }

            modeloTabla.setModoEdicion(true);

            // Seleccionar la fila correspondiente
            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                if (modeloTabla.getClienteAt(i).getIdCliente().equals(clienteSeleccionado.getIdCliente())) {
                    tablaClientes.setRowSelectionInterval(i, i);
                    tablaClientes.scrollRectToVisible(tablaClientes.getCellRect(i, 1, true));
                    tablaClientes.editCellAt(i, 1); // Empezar edición en columna Nombre
                    break;
                }
            }

            ComboBoxClientes.setEnabled(false);
            btnBuscar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnGuardarCambios.setEnabled(true);
            btnEditar.setEnabled(false);
            btnRegistrar.setEnabled(false);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al iniciar edición: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        // Verificar si hay un cliente seleccionado en el ComboBox
        if (ComboBoxClientes.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this,
                    "Por favor seleccione un cliente de la lista",
                    "Selección requerida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

// Obtener el cliente seleccionado
        String nombreSeleccionado = ComboBoxClientes.getSelectedItem().toString();
        Cliente cli = mapaClientes.get(nombreSeleccionado.toLowerCase());

        if (cli == null) {
            JOptionPane.showMessageDialog(this,
                    "No se encontró el cliente seleccionado",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

// Confirmar 
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Estás seguro de eliminar a " + cli.getNombreCliente() + "?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                //Eliminar de la base de datos
                clienteJpaController.destroy(cli.getIdCliente());

                //Eliminar de las estructuras de datos
                listaClientes.removeIf(c -> c.getIdCliente().equals(cli.getIdCliente()));
                mapaClientes.remove(cli.getNombreCliente().toLowerCase());
                mapaClientes.remove(cli.getIdCliente().toString());

                //Actualizar  ComboBox 
                cargarClientesEnCombo();

                //Actualizar la tabla
                modeloTabla.actualizarDatosCompletos(listaClientes);

                clienteSeleccionado = null;
                btnEditar.setEnabled(false);
                btnEliminar.setEnabled(false);

                JOptionPane.showMessageDialog(this,
                        cli.getNombreCliente() + " ha sido eliminado correctamente",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Error al eliminar: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnGuardarCambiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarCambiosActionPerformed
        // TODO add your handling code here:
        try {
            if (tablaClientes.isEditing()) {
                tablaClientes.getCellEditor().stopCellEditing();
            }

            //Obtener clientes modificados
            List<Cliente> modificados = modeloTabla.getClientesModificados();

            if (modificados.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No hay cambios para guardar.",
                        "Información",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            //Guardar cambios en la base de datos
            for (Cliente c : modificados) {
                clienteJpaController.edit(c);
                System.out.println("Guardando cambios para ID: " + c.getIdCliente());
            }

            //Actualizar datos 
            listaClientes = clienteJpaController.findClienteEntities();
            actualizarMapaClientes();

            // actualizar ComboBox 
            ComboBoxClientes.removeAllItems();
            ComboBoxClientes.addItem("Selecciona un cliente");

            // Ordenar clientes por registro
            listaClientes.sort(Comparator.comparing(Cliente::getIdCliente));

            for (Cliente cli : listaClientes) {
                if (cli.getNombreCliente() != null && !cli.getNombreCliente().trim().isEmpty()) {
                    ComboBoxClientes.addItem(cli.getNombreCliente().trim());
                }
            }

            //limpiar combo
            ComboBoxClientes.setSelectedIndex(0);

            // Actualizar modelo y vista
            modeloTabla.actualizarDatosCompletos(listaClientes);
            modeloTabla.setModoEdicion(false);

            btnEditar.setEnabled(false);
            btnGuardarCambios.setEnabled(false);
            btnEliminar.setEnabled(false);
            ComboBoxClientes.setEnabled(true);
            btnBuscar.setEnabled(true);
            btnRegistrar.setEnabled(true);

            //confirmación
            JOptionPane.showMessageDialog(this,
                    "Cambios guardados correctamente. El ComboBox ha sido actualizado.",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar cambios: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }

    }//GEN-LAST:event_btnGuardarCambiosActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        if (tablaClientes.isEditing()) {
            tablaClientes.getCellEditor().stopCellEditing();
        }

        restaurarEstadoCompleto();
        ComboBoxClientes.setEnabled(true);
        btnBuscar.setEnabled(true);
        btnGuardarCambios.setEnabled(false);
        btnRegistrar.setEnabled(true);
        btnEditar.setEnabled(false);
        btnEliminar.setEnabled(false);
        limpiarCampos();
        txtNombre.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCorreo.setEnabled(false);
        btnAceptarRegistro.setEnabled(false);

//confirmación
        JOptionPane.showMessageDialog(this,
                "Operación cancelada. Mostrando lista completa de clientes.",
                "Cancelado",
                JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ICliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ICliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ICliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ICliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ICliente dialog = new ICliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxClientes;
    private javax.swing.JButton btnAceptarRegistro;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarCambios;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCorreo;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelTelefono;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
