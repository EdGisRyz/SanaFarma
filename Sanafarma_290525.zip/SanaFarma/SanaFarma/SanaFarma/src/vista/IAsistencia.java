/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package vista;

import control.AsistenciaJpaController;
import control.EmpleadoJpaController;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.Asistencia;
import modelo.AsistenciaTableModel;
import modelo.Empleado;
import java.util.Arrays;
import java.util.Calendar;

/**
 *
 * @author Biani
 */
public class IAsistencia extends javax.swing.JDialog {

    private Map<String, Empleado> mapaEmpleados = new HashMap<>();
    private List<Empleado> listaEmpleados = new ArrayList<>();
    private EmpleadoJpaController empleadoJpaController;
    private AsistenciaTableModel modeloTabla;

    public IAsistencia(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
        empleadoJpaController = new EmpleadoJpaController(emf);
        btnRegistrarEntrada.setEnabled(false);
        btnRegistrarSalida.setEnabled(false);
        cargarEmpleadosEnCombo();
        modeloTabla = new AsistenciaTableModel(new ArrayList<>());
        TablaAsistencia.setModel(modeloTabla);
        ComboBoxEmpleados.addActionListener(e -> cargarAsistencias());
        //btnHistorialAsistencia.addActionListener(e -> mostrarHistorial());


    }

    private void cargarEmpleadosEnCombo() {
        ComboBoxEmpleados.removeAllItems();
        ComboBoxEmpleados.addItem("Selecciona un empleado");

        listaEmpleados = empleadoJpaController.findEmpleadoEntities();
        mapaEmpleados.clear();

        for (Empleado emp : listaEmpleados) {
            String nombre = emp.getNombreEmpleado().trim();
            ComboBoxEmpleados.addItem(nombre); // Agrega solo el nombre al ComboBox
            mapaEmpleados.put(nombre.toLowerCase(), emp); 
        }

    }

    private void actualizarFaltasAutomaticas() {
        modeloTabla = (AsistenciaTableModel) TablaAsistencia.getModel();

        LocalTime horaFinJornada = LocalTime.of(17, 0);
        LocalTime horaLimite = horaFinJornada.plusMinutes(1); 

        LocalTime ahora = LocalTime.now();

        if (ahora.isBefore(horaLimite)) {
            // Todavía no pasó el tiempo para marcar faltas
            return;
        }

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            Asistencia asistencia = modeloTabla.getAsistenciaEnFila(i);

            if (asistencia.getHoraEntrada() == null) {
                asistencia.setEstadoEntrada("Falta");
            }

            if (asistencia.getHoraSalida() == null) {
                asistencia.setEstadoEntrada("Falta");
            }

        }

        modeloTabla.fireTableDataChanged();
    }

   private void cargarAsistencias() {
    try {
        String nombreSeleccionado = (String) ComboBoxEmpleados.getSelectedItem();
        if (nombreSeleccionado == null || nombreSeleccionado.equals("Selecciona un empleado")) {
            modeloTabla.setAsistencias(new ArrayList<>());
            return;
        }

        Empleado empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
        if (empleadoSeleccionado == null) {
            modeloTabla.setAsistencias(new ArrayList<>());
            return;
        }

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
        AsistenciaJpaController asistenciaController = new AsistenciaJpaController(emf);

        Date fechaActual = java.sql.Date.valueOf(LocalDate.now());
        Asistencia asistenciaHoy = asistenciaController.findAsistenciaPorEmpleadoYFecha(
                empleadoSeleccionado.getIdEmpleado(), fechaActual
        );

        if (asistenciaHoy != null) {
            List<Asistencia> lista = new ArrayList<>();
            lista.add(asistenciaHoy);
            modeloTabla.setAsistencias(lista);
        } else {
            modeloTabla.setAsistencias(new ArrayList<>());
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar asistencias: " + e.getMessage());
        e.printStackTrace();
    }
}


    
    private Date limpiarFecha(Date fechaConHora) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(fechaConHora);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    return cal.getTime();
}


    private boolean esMismaFecha(Date fecha1, Date fecha2) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(fecha1).equals(sdf.format(fecha2));
    }
    
    private Date convertirLocalTimeADate(LocalTime hora) {
    return Date.from(hora.atDate(LocalDate.now())
                     .atZone(ZoneId.systemDefault())
                     .toInstant());
}
    
    private void mostrarHistorial() {
    try {
        String nombreSeleccionado = (String) ComboBoxEmpleados.getSelectedItem();
        if (nombreSeleccionado == null || nombreSeleccionado.equals("Selecciona un empleado")) {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado válido.");
            return;
        }

        Empleado empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
        if (empleadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Empleado no encontrado.");
            return;
        }

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
        AsistenciaJpaController asistenciaController = new AsistenciaJpaController(emf);

        List<Asistencia> listaHistorial = asistenciaController.findAsistenciasPorEmpleado(empleadoSeleccionado.getIdEmpleado());

        if (listaHistorial == null || listaHistorial.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay historial para este empleado.");
            ComboBoxEmpleados.setSelectedIndex(0);  // limpiarel ComboBox
            modeloTabla.limpiarAsistencias(); // Limpiar la tabla
            return;
        }

        JOptionPane.showMessageDialog(this, "MOSTRANDO HISTORIAL DE ASISTENCIA");
        modeloTabla = new AsistenciaTableModel(listaHistorial);
        TablaAsistencia.setModel(modeloTabla);

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar historial: " + ex.getMessage());
        ex.printStackTrace();
    }
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        labelEmpleados = new javax.swing.JLabel();
        ComboBoxEmpleados = new javax.swing.JComboBox<>();
        btnHistorialAsistencia = new javax.swing.JButton();
        btnRegistrarEntrada = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaAsistencia = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        btnRegistrarSalida = new javax.swing.JButton();
        btnAceptar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 153, 255));
        jLabel1.setText("ASISTENCIA");

        labelEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelEmpleados.setText("Empleados");

        ComboBoxEmpleados.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnHistorialAsistencia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscInventario.png"))); // NOI18N
        btnHistorialAsistencia.setText("Historial de Asistencia");
        btnHistorialAsistencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialAsistenciaActionPerformed(evt);
            }
        });

        btnRegistrarEntrada.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editar.png"))); // NOI18N
        btnRegistrarEntrada.setText("Registrar Entrada");
        btnRegistrarEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarEntradaActionPerformed(evt);
            }
        });

        TablaAsistencia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TablaAsistencia);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Tabla Asistencia");

        btnRegistrarSalida.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editar.png"))); // NOI18N
        btnRegistrarSalida.setText("Registrar Salida");
        btnRegistrarSalida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarSalidaActionPerformed(evt);
            }
        });

        btnAceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscarProveedor.png"))); // NOI18N
        btnAceptar.setText("Buscar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/regresar.png"))); // NOI18N
        btnSalir.setText("Regresar");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(209, 209, 209)
                        .addComponent(btnRegistrarSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(labelEmpleados)
                        .addGap(231, 231, 231)
                        .addComponent(btnRegistrarEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ComboBoxEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnHistorialAsistencia, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(138, 138, 138))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 888, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(427, 427, 427)
                        .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(412, 412, 412)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))))
                .addGap(0, 39, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelEmpleados)
                    .addComponent(btnRegistrarEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnHistorialAsistencia, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(btnRegistrarSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        try {
            String nombreSeleccionado = (String) ComboBoxEmpleados.getSelectedItem();
            if (nombreSeleccionado == null || nombreSeleccionado.equals("Selecciona un empleado")) {
                JOptionPane.showMessageDialog(this, "Por favor selecciona un empleado válido.");
                return;
            }

            Empleado empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
            if (empleadoSeleccionado == null) {
                JOptionPane.showMessageDialog(this, "Empleado no encontrado.");
                return;
            }

            // Verificar si ya hay una fila para este empleado para el dia
            for (Asistencia asistencia : modeloTabla.getListaAsistencias()) {
                if (asistencia.getIdEmpleado().getIdEmpleado().equals(empleadoSeleccionado.getIdEmpleado())
                        && esMismaFecha(asistencia.getFecha(), new Date())) {
                    JOptionPane.showMessageDialog(this, "Ya se ha creado un registro de asistencia para este empleado hoy.");
                    return;
                }
            }

            // Crear una nueva asistencia con la fecha actual
            Date fechaActual = new Date();
            Asistencia nuevaAsistencia = new Asistencia(null, fechaActual);
            nuevaAsistencia.setIdEmpleado(empleadoSeleccionado);
            nuevaAsistencia.setFecha(fechaActual);
            nuevaAsistencia.setHoraEntrada(null);
            nuevaAsistencia.setEstadoEntrada("Pendiente");  
            nuevaAsistencia.setHoraSalida(null);
            nuevaAsistencia.setEstadoSalida("Pendiente");  

            modeloTabla.agregarAsistencia(nuevaAsistencia);

            btnRegistrarEntrada.setEnabled(true);
            btnRegistrarSalida.setEnabled(true);
            btnAceptar.setEnabled(false);
            ComboBoxEmpleados.setEnabled(false);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }

    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnRegistrarEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarEntradaActionPerformed
       try {
        String nombreSeleccionado = (String) ComboBoxEmpleados.getSelectedItem();
        if (nombreSeleccionado == null || nombreSeleccionado.equals("Selecciona un empleado")) {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado válido.");
            return;
        }

        Empleado empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
        if (empleadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el empleado seleccionado.");
            return;
        }

        LocalDate fechaActual = LocalDate.now();
        LocalTime horaActual = LocalTime.now();
        Date fechaSql = java.sql.Date.valueOf(fechaActual);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
        AsistenciaJpaController asistenciaController = new AsistenciaJpaController(emf);

        // Buscar si ya existe registro para el dia
        Asistencia asistenciaExistente = asistenciaController.findAsistenciaPorEmpleadoYFecha(empleadoSeleccionado.getIdEmpleado(), fechaSql);

        if (asistenciaExistente != null && asistenciaExistente.getHoraEntrada() != null) {
            JOptionPane.showMessageDialog(this, "Ya se registró la hora de entrada para hoy.");
            return;
        }

        if (asistenciaExistente == null) {
            // Crear nueva asistencia
            Asistencia nuevaAsistencia = new Asistencia();
            nuevaAsistencia.setIdEmpleado(empleadoSeleccionado);
            nuevaAsistencia.setFecha(fechaSql);
            nuevaAsistencia.setHoraEntrada(java.sql.Time.valueOf(horaActual));

            // Estado entrada
            LocalTime horaLimite = LocalTime.of(9, 0);
            String estadoEntrada = horaActual.isAfter(horaLimite) ? "Retardo" : "Asistencia";
            nuevaAsistencia.setEstadoEntrada(estadoEntrada);

            // Estado salida pendiente
            nuevaAsistencia.setEstadoSalida("Pendiente");

            asistenciaController.create(nuevaAsistencia);
            JOptionPane.showMessageDialog(this, "Hora de entrada registrada con estado: " + estadoEntrada);
        } else {
            //actualizar la hora de entrada y estado entrada 
            asistenciaExistente.setHoraEntrada(java.sql.Time.valueOf(horaActual));
            LocalTime horaLimite = LocalTime.of(9, 0);
            String estadoEntrada = horaActual.isAfter(horaLimite) ? "Retardo" : "Asistencia";
            asistenciaExistente.setEstadoEntrada(estadoEntrada);

            //estado salida pendiente si está vacío
            if (asistenciaExistente.getEstadoSalida() == null) {
                asistenciaExistente.setEstadoSalida("Pendiente");
            }

            asistenciaController.edit(asistenciaExistente);
            JOptionPane.showMessageDialog(this, "Hora de entrada actualizada con estado: " + estadoEntrada);
        }

        cargarAsistencias();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al registrar entrada: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnRegistrarEntradaActionPerformed

    private void btnRegistrarSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarSalidaActionPerformed
        try {
        String nombreSeleccionado = (String) ComboBoxEmpleados.getSelectedItem();
        if (nombreSeleccionado == null || nombreSeleccionado.equals("Selecciona un empleado")) {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado válido.");
            return;
        }

        Empleado empleadoSeleccionado = mapaEmpleados.get(nombreSeleccionado.toLowerCase());
        if (empleadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el empleado seleccionado.");
            return;
        }

        LocalDate fechaActual = LocalDate.now();
        LocalTime horaActual = LocalTime.now();
        Date fechaSql = java.sql.Date.valueOf(fechaActual);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("sanafarma");
        AsistenciaJpaController asistenciaController = new AsistenciaJpaController(emf);

        Asistencia asistenciaExistente = asistenciaController.findAsistenciaPorEmpleadoYFecha(empleadoSeleccionado.getIdEmpleado(), fechaSql);

        if (asistenciaExistente == null || asistenciaExistente.getHoraEntrada() == null) {
            JOptionPane.showMessageDialog(this, "Primero debes registrar la hora de entrada.");
            return;
        }

        if (asistenciaExistente.getHoraSalida() != null) {
            JOptionPane.showMessageDialog(this, "Ya se ha registrado la hora de salida para hoy.");
            return;
        }

        // Registrar hora salida
        asistenciaExistente.setHoraSalida(java.sql.Time.valueOf(horaActual));

        // Calcular horas trabajadas
        long diferenciaMillis = asistenciaExistente.getHoraSalida().getTime() - asistenciaExistente.getHoraEntrada().getTime();
        long horasTrabajadas = diferenciaMillis / (1000 * 60 * 60);

        // Estado salida
        if (horasTrabajadas >= 8) {
            asistenciaExistente.setEstadoSalida("Cumplió jornada laboral");
        } else {
            asistenciaExistente.setEstadoSalida("No cumplió jornada laboral");
        }

        asistenciaController.edit(asistenciaExistente);

        JOptionPane.showMessageDialog(this, "Hora de salida registrada con estado: " + asistenciaExistente.getEstadoSalida());

        cargarAsistencias();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al registrar salida: " + e.getMessage());
        e.printStackTrace();
    }
 
    }//GEN-LAST:event_btnRegistrarSalidaActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
    // Limpiar tabla en memoria
    modeloTabla.limpiarAsistencias();

    // limpiar ComboBox 
    ComboBoxEmpleados.setSelectedIndex(0);

    //vomponentes
    btnAceptar.setEnabled(true);
    btnRegistrarEntrada.setEnabled(false);
    btnRegistrarSalida.setEnabled(false);
    ComboBoxEmpleados.setEnabled(true);

    
    cargarAsistencias();  
    
    dispose();

    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnHistorialAsistenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialAsistenciaActionPerformed
        // TODO add your handling code here:
        mostrarHistorial();
        ComboBoxEmpleados.setEnabled(true);
        btnAceptar.setEnabled(true);
    }//GEN-LAST:event_btnHistorialAsistenciaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IAsistencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IAsistencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IAsistencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IAsistencia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                IAsistencia dialog = new IAsistencia(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxEmpleados;
    private javax.swing.JTable TablaAsistencia;
    private javax.swing.JButton btnAceptar;
    private javax.swing.JButton btnHistorialAsistencia;
    private javax.swing.JButton btnRegistrarEntrada;
    private javax.swing.JButton btnRegistrarSalida;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelEmpleados;
    // End of variables declaration//GEN-END:variables
}
